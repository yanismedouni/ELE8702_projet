import numpy as np
from lab3_eq2 import *
import math

def check_visibility(file_name, ue_id, antenna_id):
    with open(file_name, "r") as file:
        lines = file.readlines()
    
    # Parsing the visibility file
    visibility_dict = {}
    for line in lines:
        data = list(map(int, line.strip().split()))
        if data:
            ue = data[0]  # First element is the UE ID
            antennas = set(data[1:])  # Remaining elements are visible antennas
            visibility_dict[ue] = antennas

    # Check if the UE exists in the visibility data
    if ue_id in visibility_dict:
        if (antenna_id in visibility_dict[ue_id]):
            return 'los'
        else:
            return 'nlos'
    else:
        return 'nlos'

def rma_LOS(fc, d_2D, h, h_ut, h_bs, w):
    """
    Calcule le path loss pour un scénario Rural Macro (RMa) en Line-of-Sight (LoS).
    
    Paramètres :
    - fc : Fréquence en GHz
    - d_2D : Distance 2D entre la station de base et l'UE en mètres
    - h : Hauteur des bâtiments en mètres
    - h_ut : Hauteur de l'UE en mètres
    - h_bs : Hauteur de la station de base en mètres
    - w : Largeur de la rue en mètres

    Retourne :
    - Path loss en dB
    """
    d_BP = 2 * math.pi * h_bs * h_ut * fc * 1e9 / 3e8  # Distance de rupture
    d_3D = math.sqrt(d_2D**2 + (h_bs - h_ut)**2)  # Distance 3D

    if fc < 0.5 or fc > 30:
        print("Fréquence hors plage. Veuillez changer le groupe d'antennes.")
    if h_bs < 10 or h_bs > 150:
        print("Hauteur de l'antenne hors plage.")
    if h_ut < 1 or h_ut > 10:
        print("Hauteur de l'UE hors plage.")

    if d_2D > 10000:
        pathloss = math.inf  # Pathloss infini si distance > 10 km
    elif d_2D < 10:
        pathloss = 0  # Aucune perte pour distances très courtes
    elif d_2D < d_BP:
        pathloss = 20 * math.log10(40 * math.pi * d_3D * fc / 3) + \
                   min(0.03 * (h**1.72), 10) * math.log10(d_3D) - \
                   min(0.044 * (h**1.72), 14.77) + \
                   0.002 * math.log10(h) * d_3D
    else:
        PL1 = 20 * math.log10(40 * math.pi * d_BP * fc / 3) + \
              min(0.03 * (h**1.72), 10) * math.log10(d_BP) - \
              min(0.044 * (h**1.72), 14.77) + \
              0.002 * math.log10(h) * d_BP
        pathloss = PL1 + 40 * math.log10(d_3D / d_BP)

    return pathloss

def rma_NLOS(fc, d_2D, h, h_ut, h_bs, w):
    """
    Calcule le path loss pour un scénario Rural Macro (RMa) en Non-Line-of-Sight (NLoS).
    """
    d_3D = math.sqrt(d_2D**2 + (h_bs - h_ut)**2)

    pathloss = 161.04 - 7.1 * math.log10(w) + 7.5 * math.log10(h) - \
               (24.37 - 3.7 * (h / h_bs)**2) * math.log10(h_bs) + \
               (43.42 - 3.1 * math.log10(h_bs)) * (math.log10(d_3D) - 3) + \
               20 * math.log10(fc) - (3.2 * (math.log10(11.75 * h_ut))**2 - 4.97)

    return max(pathloss, rma_LOS(fc, d_2D, h, h_ut, h_bs, w))

def uma_LOS(fc, d_2D, h, h_ut, h_bs, w):
    """
    Calcule le path loss pour un scénario Urban Macro (UMa) en Line-of-Sight (LoS).
    """
    d_BP = 2 * math.pi * h_bs * h_ut * fc * 1e9 / 3e8
    d_3D = math.sqrt(d_2D**2 + (h_bs - h_ut)**2)

    if fc < 0.5 or fc > 100:
        print("Fréquence hors plage. Veuillez changer le groupe d'antennes.")
    if h_bs < 25:
        print("Hauteur de l'antenne trop petite pour UMa (h ≥ 25m).")
    if h_ut < 1.5 or h_ut > 22.5:
        print("Hauteur de l'UE hors plage.")

    if d_2D > 5000:
        pathloss = math.inf
    elif d_2D < 10:
        pathloss = 0
    elif d_2D < d_BP:
        pathloss = 28 + 22 * math.log10(d_3D) + 20 * math.log10(fc)
    else:
        pathloss = 28 + 40 * math.log10(d_3D) + 20 * math.log10(fc) - \
                   9 * math.log10((d_BP)**2 + (h_bs - h_ut)**2)

    return pathloss

def uma_NLOS(fc, d_2D, h, h_ut, h_bs, w):
    """
    Calcule le path loss pour un scénario Urban Macro (UMa) en Non-Line-of-Sight (NLoS).
    """
    d_3D = math.sqrt(d_2D**2 + (h_bs - h_ut)**2)

    pathloss = 13.54 + 39.08 * math.log10(d_3D) + 20 * math.log10(fc) - \
               0.6 * (h_ut - 1.5)

    return max(pathloss, uma_LOS(fc, d_2D, h, h_ut, h_bs, w))

def umi_LOS(fc, d_2D, h, h_ut, h_bs, w):
    """
    Calcule le path loss pour un scénario Urban Micro (UMi) en Line-of-Sight (LoS).
    """
    d_BP = 2 * math.pi * h_bs * h_ut * fc * 1e9 / 3e8
    d_3D = math.sqrt(d_2D**2 + (h_bs - h_ut)**2)

    if fc < 0.5 or fc > 100:
        print("Fréquence hors plage. Veuillez changer le groupe d'antennes.")
    if h_bs < 10 or h_bs > 25:
        print("Hauteur de l'antenne hors plage.")
    if h_ut < 1.5 or h_ut > 22.5:
        print("Hauteur de l'UE hors plage.")

    if d_2D > 5000:
        pathloss = math.inf
    elif d_2D < 10:
        pathloss = 0
    elif d_2D < d_BP:
        pathloss = 32.4 + 21 * math.log10(d_3D) + 20 * math.log10(fc)
    else:
        pathloss = 32.4 + 40 * math.log10(d_3D) + 20 * math.log10(fc) - \
                   9.5 * math.log10((d_BP)**2 + (h_bs - h_ut)**2)

    return pathloss

def umi_NLOS(fc, d_2D, h, h_ut, h_bs, w):
    """
    Calcule le path loss pour un scénario Urban Micro (UMi) en Non-Line-of-Sight (NLoS).
    """
    d_3D = math.sqrt(d_2D**2 + (h_bs - h_ut)**2)

    pathloss = 22.4 + 35.3 * math.log10(d_3D) + 21.3 * math.log10(fc) - \
               0.3 * (h_ut - 1.5)

    return max(pathloss, umi_LOS(fc, d_2D, h, h_ut, h_bs, w))

