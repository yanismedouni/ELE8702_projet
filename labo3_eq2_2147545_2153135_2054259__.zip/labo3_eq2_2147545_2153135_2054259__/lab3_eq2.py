## Labo2
## equipe 2
## Massine Azzoug - 2054259
## Yanis Medouni - 2153125
## Eliott Goulet - 2147545

import sys
import math
import yaml
import random
import argparse
import os
import pandas as pd
import numpy as np
import pathloss_3gpp_eq2
from pathloss_3gpp_eq2 import *
import matplotlib.pyplot as plt
import seaborn as sns

random.seed(123)

class Antenna:

     def __init__(self, id):
        self.id = id          #id de l'antenne (int)
        self.frequency = None # Antenna frequency in GHz
        self.height = None    # Antenna height
        self.group = None     # group défini dans la base de données (str)
        self.coords = None    # tuple contenant les coordonnées (x,y) 
        self.assoc_ues = []   # liste avec les id des UEs associés à l'antenne
        self.scenario = None  # pathloss scénario tel que lu du fichier de cas (str)
        self.gen = None       # type de géneration de coordonnées: 'g', 'a', etc. (str)
        self.bit_par_slot = []# Nombre de bits lus par l'antenne par slot
        self.timeslots = []   # Temps au debut de chaque slot
        self.slot_ues = [[]]  # ID des UEs actifs pendant chaque slot
    
    
    
class UE:

     def __init__(self, id, app_name):
        self.id= id           # id de l'UE (int)
        self.height = None    # UE height
        self.group = None     # group défini dans la base de données (str)
        self.coords=None      # tuple contenant les coordonnées (x,y) 
        self.app=app_name     # nom de l'application qui tourne dans le UE (str)
        self.assoc_ant=None   # id de l'antenne associée à l'UE (int)
        self.los = True       # LoS ou non (bool)
        self.gen = None       # type de géneration de coordonnées: 'g', 'a', etc. (str)
        self.debit = None     # Débit de transmission
        self.bit_par_slot = []
        self.timeslots = []


def find_items_by_field(data, branch_name, target_key, target_value):
    matching_keys = []
    branch = data.get(branch_name, {})

    if not isinstance(branch, dict):
        raise ValueError(f"Expected a dict under branch '{branch_name}', got {type(branch)}")

    for item_name, item_data in branch.items():
        if isinstance(item_data, dict) and item_data.get(target_key) == target_value:
            matching_keys.append(item_name)

    return matching_keys

def ERROR(msg , code = 1):
    print("\n\n\nERROR\nPROGRAM STOPPED!!!\n")
    if msg:
        print(msg)
    print(f"\n\texit code = {code}\n\n\t\n")
    sys.exit(code)

def fill_up_the_lattice(N, lh, lv, nh, nv):
    """Function appelée par get_rectangle_lattice_coords()"""
    
    def get_delta1d(L, n):
        return L/(n + 1)
    
    coords = []
    deltav = get_delta1d(lv, nv)
    deltah = get_delta1d(lh, nh)
    line = 1
    y = deltav
    count = 0
    while count < N:
        if count + nh < N:
            x = deltah
            for  i in range(nh):
                # Fill up the horizontal line
                coords.append((x,y))
                x = x + deltah
                count += 1
            line += 1
        else:
            deltah = get_delta1d(lh, N - count)
            x = deltah
            for i in range(N - count):
                # Fill up the last horizontal line
                coords.append((x,y))
                x = x + deltah
                count += 1
            line += 1
        y = y +deltav
    return coords

def get_rectangle_lattice_coords(lh, lv, N, Np, nh, nv):
    """Function appelee par gen_lattice_coords()"""
    
    if Np > N:
        coords = fill_up_the_lattice(N, lh, lv, nh, nv)
    elif Np < N:
        coords = fill_up_the_lattice(N, lh, lv, nh, nv + 1)
    else:
        coords = fill_up_the_lattice(N, lh, lv, nh, nv)
    return coords

def gen_lattice_coords(terrain_shape: dict, N: int):

    shape = list(terrain_shape.keys())[0]
    lh = terrain_shape[shape]['length']
    lv = terrain_shape[shape]['height']
    R = lv / lh    
    nv = round(math.sqrt(N / R))
    nh = round(R * nv)
    Np = nh * nv
    if shape.lower() == 'rectangle':
        coords = get_rectangle_lattice_coords(lh, lv, N, Np, nh, nv)
    else:
        msg = [f"\tImproper shape ({shape}) used in the\n",
                "\tgeneration of lattice coordinates.\n"
                "\tValid values: ['rectangle']"]
        ERROR(''.join(msg), 2)
    return coords        

def get_from_dict(key, data, res=None, curr_level = 1, min_level = 1):
    if res:
        return res
    if type(data) is not dict:
        msg = f"get_from_dict() works with dicts and is receiving a {type(data)}"
        ERROR(msg, 1)
    else:
        # data IS a dictionary
        for k, v in data.items():
            if k == key and curr_level >= min_level:
                #print(f"return data[k] = {data[k]} k = {k}")
                return data[k]
            if type(v) is dict:
                level = curr_level + 1
                res = get_from_dict(key, v, res, level, min_level)
    return res 

def write_coords_to_file(antennas, ues, filename="lab3_eq2_coords.txt"):

    # Prepare combined data
    data = []

    for i, antenna in enumerate(antennas):
        if antenna.coords is not None:
            x, y = antenna.coords
            data.append(["antenna", f"{antenna.id}", f"{antenna.group}", f"{x}", f"{y}", ""])  

    for i, ue in enumerate(ues):
        if ue.coords is not None:
            x, y = ue.coords
            data.append(["ue", f"{ue.id}", f"{ue.group}", f"{x}", f"{y}", ue.app])

    # Create DataFrame
    df = pd.DataFrame(data, columns=["Type", "Index", "Name", "X", "Y", "App"])

    # Convert to string manually to ensure proper alignment
    lines = []
    for row in df.itertuples(index=False, name=None):
        line = f"{row[0]:<10} {row[1]:<5} {row[2]:<15} {row[3]:<20} {row[4]:<20} {row[5]:<10}"
        lines.append(line)

    # Write to file
    with open(filename, 'w') as file:
        file.write("\n".join(lines))

def read_yaml_file(fname):
    if not os.path.isfile(fname):
        print(f"Erreur : Le fichier '{fname}' n'existe pas.")
        return None
        
    try:
        with open(fname, 'r', encoding='utf-8') as file:
            data = yaml.safe_load(file)
            return data
    except yaml.YAMLError as e:
        print(f"Erreur lors de la lecture du fichier YAML : {e}")
    except Exception as e:
        print(f"Erreur inattendue : {e}")
    
    return None

def gen_random_coords(terrain_shape : dict, size):
    # Cette fonction doit générer les coordonées pour le cas de positionnement aléatoire
    # TODO
    coords = []
    shape = list(terrain_shape.keys())[0]
    lenX = terrain_shape[shape]['length']
    lenY = terrain_shape[shape]['height']
    for coord in range(size):
        PosX = round(random.uniform(0, lenX), 2)
        PosY = round(random.uniform(0, lenY), 2)
        coords.append([PosX,PosY])
    return coords

def gen_coords(device_list, gen, surface):
    coords = []
    if(gen == 'g'):
        coords = gen_lattice_coords(surface, len(device_list))
    else:
        coords = gen_random_coords(surface, len(device_list)) 
    for i in range(len(device_list)):
        device_list[i].coords = coords[i]

    return device_list

def get_coords_from_file(antennas, ues, filename):
    if not os.path.isfile(filename):
        ERROR(f"File '{filename}' not found.")

    try:
        with open(filename, 'r') as file:
            lines = file.readlines()

        for line in lines:
            parts = line.strip().split()
            if len(parts) < 5:
                continue 

            dev_type, dev_id, _, x, y = parts[:5]
            x, y = float(x), float(y)

            if dev_type == "antenna":
                for antenna in antennas:
                    if antenna.id == int(dev_id):
                        antenna.coords = (x, y)
                        break
            elif dev_type == "ue":
                for ue in ues:
                    if ue.id == int(dev_id):
                        ue.coords = (x, y)
                        break

    except Exception as e:
        ERROR(f"Error reading coordinates file: {e}")

    return antennas, ues


def get_pathloss(antennas, ues, model, scenario, visibilityFile):
    pathlossTab = []
    if model == 'okumura':
        for ue in ues:
            pathlosses = []
            for antenna in antennas:
                pathloss = okumura(antenna.frequency, math.dist(antenna.coords, ue.coords), antenna.height, ue.height, scenario)
                pathlosses.append(pathloss)
                pathlossTab.append(pathlosses)
            best_antenna = pathlosses.index(min(pathlosses))
            ue.assoc_ant = antennas[best_antenna].id
            antennas[best_antenna].assoc_ues.append(ue.id)
    elif model == '3gpp':
        for ue in ues:
            pathlosses = []
            for antenna in antennas:
                visibility = check_visibility(visibilityFile, ue.id, antenna.id)
                pathloss = gpp(scenario, antenna.frequency, antenna.height, ue.height, math.dist(antenna.coords, ue.coords), visibility)
                pathlosses.append(pathloss)
                pathlossTab.append(pathlosses)
            best_antenna = pathlosses.index(min(pathlosses))
            ue.assoc_ant = antennas[best_antenna].id
            antennas[best_antenna].assoc_ues.append(ue.id)
    else :
        ERROR("Veuillez utiliser le model okumura ou 3gpp")
    return antennas, ues, pathlossTab

def gpp(scenario, fc, h_bs, h_ut, d_2D, type):
    #Fonction de calcul de PathLoss avec 3gpp
    h = 5
    hE = 1
    w = 20
    if(scenario.lower() == "rma"):
        if(type == 'los'):
            pathloss = pathloss_3gpp_eq2.rma_LOS(fc, d_2D, h, h_ut, h_bs, w)
        else:
            pathloss = pathloss_3gpp_eq2.rma_NLOS(fc, d_2D, h, h_ut, h_bs, w)
    elif(scenario.lower() == "uma"):
        if(type == 'los'):
            pathloss = pathloss_3gpp_eq2.uma_LOS(fc, d_2D, h, h_ut, h_bs, w)
        else:
            pathloss = pathloss_3gpp_eq2.uma_NLOS(fc, d_2D, h, h_ut, h_bs, w)
    elif(scenario.lower() == "umi"):
        if(type == 'los'):
            pathloss = pathloss_3gpp_eq2.umi_LOS(fc, d_2D, h, h_ut, h_bs, w)
        else:
            pathloss = pathloss_3gpp_eq2.umi_NLOS(fc, d_2D, h, h_ut, h_bs, w)
    else:
        ERROR("Veuillez rentrer un nom de scenario valide svp. (UMi, UMa ou RMa)")

    return pathloss

def lab0 (data_case, data_devices):

    #create empty arrays
    antennas = []
    ues = []

    #set indexes for IDs and array values
    antIndex = 0
    ueIndex = 0

    #parses through the case devices and fill the arrays
    DEVICES = get_from_dict('DEVICES', data_case)
    for device_name, device_data in DEVICES.items():
        #parses through
        device = get_from_dict(device_name, data_devices)
        device_type = get_from_dict('type', device) 
        #create device and add to array
        for i in range(get_from_dict('number', device_data)):  
            if(device_type == "antenna"):
                antenna = Antenna(antIndex)
                antenna.group = get_from_dict('name', device) 
                group = find_items_by_field(data_devices, "ANTENNAS", "name", antenna.group)
                antenna.height = get_from_dict('height',data_devices["ANTENNAS"][group[0]])          # 3e élément du dict, soit la hauteur
                antenna.frequency = get_from_dict('frequency',data_devices["ANTENNAS"][group[0]])
                antenna.gen = get_from_dict('ANT_COORD_GEN', data_case)
                antennas.append(antenna)
                antIndex += 1
            else:
                ue = UE(ueIndex, get_from_dict('app', device))            
                ue.group = get_from_dict('name', device)  
                group = find_items_by_field(data_devices, "UES", "name", ue.group)   
                ue.height = get_from_dict('height',data_devices["UES"][group[0]])            
                ue.gen = get_from_dict('UE_COORD_GEN', data_case)
                ues.append(ue)
                ueIndex += 1
            
    #get the coordinates for the arrays    
    if get_from_dict("COORD_FILES", data_case) is not None:
        if get_from_dict("read", get_from_dict("COORD_FILES", data_case)) is not None:
            antennas, ues = get_coords_from_file(antennas, ues, get_from_dict('read', get_from_dict('COORD_FILES', data_case)))
        else:
            antennas = gen_coords(antennas, get_from_dict('ANT_COORD_GEN', data_case), get_from_dict('Surface', data_case))
            ues = gen_coords(ues, get_from_dict('UE_COORD_GEN', data_case), get_from_dict('Surface', data_case))
    
    return (antennas,ues)

# --------
#Pour lire le fichier de visibilité
def read_visibility_file(filename):
    visibility = {}
    with open(filename, 'r') as file:
        for line in file:
            line = line.strip()
            if line:
                ue, *nlos_ant = line.split()
                visibility[ue] = nlos_ant
    return visibility

def append_pathloss (antennas, ues, scenario, visibility):
    for UEitem in ues:
        pl = []
        for antitem in antennas:
            type = check_visibility(visibility, UEitem, antitem)
            pl.append(gpp(scenario, antitem.frequency, antitem.height, UEitem.height, math.dist(UEitem.coords,antitem.coords), type))
        bestant = pl.index(min(pl))
        UEitem.assoc_ant = antennas[bestant].id
        antennas[bestant].assoc_ues.append(UEitem.id)
    
    return (antennas,ues)

# Chargement des segments de temps depuis lab3_eq8_segments.txt
def load_time_segments(filename):
    segments = []
    with open(filename, 'r') as file:
        for line in file:
            ue_id, start_time, end_time = map(float, line.strip().split())
            segments.append({'ue_id': int(ue_id), 'start_time': start_time, 'end_time': end_time})
    return segments
#--------

def okumura(fc, d, h_bs, h_ut, scenario):
    # Vérification des valeurs des paramètres
    if fc < 0.25 or fc > 28:  
        ERROR("La fréquence doit être comprise entre 0.25 GHz et 28 GHz.")

    if h_bs < 10 or h_bs > 37:  
        ERROR("La hauteur de l'antenne doit être entre 10 et 37 m.")

    if h_ut != 1.5:  
        ERROR("La hauteur de l'UE doit être de 1.5 m.")

    if d > 20000:  
        return math.inf  # Path loss infini pour des distances supérieures à 20 km

    if d < 1000:
        return 0  # Path loss nul pour une distance inférieure à 1 m

    # Conversion des unités
    fc_MHz = fc * 1000  # GHz en MHz
    d_km = d / 1000  # m en km

    # Calcul du facteur de correction A
    if scenario == 'urban_large':
        if fc_MHz < 300:
            A = (8.29 * (math.log10(1.54 * h_ut)) ** 2) - 1.1
        else:
            A = (3.2 * (math.log10(11.75 * h_ut)) ** 2) - 4.97

    elif scenario == 'urban_small':
        # Le modèle "urban_small" est plus proche de "urban_large" mais avec un ajustement différent
        A = (1.1 * math.log10(fc_MHz) - 0.7) * h_ut - (1.56 * math.log10(fc_MHz) - 0.8)

    elif scenario in ['suburban', 'open']:
        A = (1.1 * math.log10(fc_MHz) - 0.7) * h_ut - (1.56 * math.log10(fc_MHz) - 0.8)

    else:
        raise ValueError("Scénario inconnu. Utilisez 'urban_large', 'urban_small', 'open' ou 'suburban'.")

    # Calcul du pathloss de base
    pathloss = 69.55 + 26.16 * math.log10(fc_MHz) - 13.82 * math.log10(h_bs) - A + (44.9 - 6.55 * math.log10(h_bs)) * math.log10(d_km)

    # Ajustements spécifiques aux scénarios
    if scenario == 'suburban':
        pathloss = pathloss - 2 * (math.log10(fc_MHz / 28)) ** 2 - 5.4

    if scenario == 'open':
        pathloss = pathloss - 4.78 * (math.log10(fc_MHz)) ** 2 + 18.733 * math.log10(fc_MHz) - 40.98

    return pathloss

def treat_cli_args(arg):
    #check number of arguments
    if len(arg) != 1:
        ERROR(f"There has to be only one argument given : the name of the case file.")
    files_in_directory = os.listdir(os.getcwd())

    #check if case file exists
    if arg[0] not in files_in_directory:
        ERROR(f"The file '{arg[0]}' was not found in the current directory.")
    case_file_name = arg[0]



    return case_file_name


def write_coords_to_file(antennas, ues, filename="lab3_eq2_coords.txt"):
    with open(filename, "w") as f:
        for antenna in antennas:
            if antenna.coords is not None:
                f.write("antenna ")
                f.write(str(antenna.id).ljust(2))
                f.write("    ")
                f.write(antenna.group.ljust(10))
                f.write("    ")
                f.write(str(antenna.coords[0]).ljust(20))  # X avec 1 chiffre après la virgule
                f.write("    ")
                f.write(str(antenna.coords[1]).ljust(20))  # Y avec 1 chiffre après la virgule
                f.write("\n")

        for ue in ues:
            if ue.coords is not None:
                f.write("ue      ")
                f.write(str(ue.id).ljust(2))
                f.write("    ")
                f.write(ue.group.ljust(10))
                f.write("    ")
                f.write(str(ue.coords[0]).ljust(20))  # X avec 1 chiffre après la virgule
                f.write("    ")
                f.write(str(ue.coords[1]).ljust(20))  # Y avec 1 chiffre après la virgule
                f.write("    ")
                f.write(ue.app.ljust(5))
                f.write("\n")



def lab3(data_case):
    data_base = read_yaml_file("devices_db.yaml")
    antennas = []
    ues = []
    antenna_ID = 0
    ueID = 0
    device_db_ANT = get_from_dict("ANTENNAS",data_base)
    device_db_UE = get_from_dict("UES",data_base)

    scenario = get_from_dict("scenario",data_case)
    scenario = scenario.lower()

    coords_dict = get_from_dict("COORD_FILES",data_case)
    coords_read_write = list(coords_dict.keys())[0]
    coords_filename = get_from_dict(coords_read_write,coords_dict)

    # Lecture des coordonnées des antennes à partir du fichier
    with open(coords_filename, "r") as coords_file:
        for line in coords_file:
            parts = line.strip().split()
            if parts[0] == "antenna":
                antenna_ID = int(parts[1])
                antennaGroup = parts[2]
                x_coord = float(parts[3])
                y_coord = float(parts[4])
                new_obj = Antenna(antenna_ID)
                new_obj.height = get_from_dict("height", device_db_ANT[antennaGroup])
                new_obj.frequency = get_from_dict("frequency", device_db_ANT[antennaGroup])
                new_obj.coords = (x_coord, y_coord)
                new_obj.gen = get_from_dict("ANT_COORD_GEN", data_case)
                new_obj.group = antennaGroup
                new_obj.scenario = scenario
                antennas.append(new_obj)

    # Lecture des coordonnées des UE à partir du fichier
    with open(coords_filename, "r") as coords_file:
        for line in coords_file:
            parts = line.strip().split()
            if parts[0] == "ue":
                ueID = int(parts[1])
                ue_group = parts[2]
                x_coord = float(parts[3])
                y_coord = float(parts[4])
                app_name = parts[5]
                new_obj = UE(ueID, app_name)
                new_obj.coords = (x_coord, y_coord)
                new_obj.gen = get_from_dict("UE_COORD_GEN", data_case)
                new_obj.group = ue_group
                new_obj.height = get_from_dict("height", device_db_UE[ue_group])
                new_obj.debit = get_from_dict("R", device_db_UE[ue_group])
                ues.append(new_obj)

    # Associations antennes et UE avec pathloss 3gpp
    visibility_dict = get_from_dict("VISIBILITY",data_case)
    vis_filename = get_from_dict("read",visibility_dict)
    model = get_from_dict('model', data_case)
    antennas, ues, pathlossesTab = get_pathloss (antennas, ues, model, scenario, vis_filename)     #Associe des pathloss aux Ues et antennes, pathloss min

    # Écriture des associations entre antennes et UE
    f = open("lab3_eq2_assoc_ant.txt", "w")
    for ant in antennas:
        f.write(str(ant.id).ljust(5))  # ID de l'antenne
        for ue_id in ant.assoc_ues:    # UE associés à cette antenne
            f.write(str(ue_id).ljust(5))
        f.write("\n")
    f.close()

    # Écriture des associations entre UE et antennes
    file = open("lab3_eq2_assoc_ue.txt", "w")
    for ue in ues:
        file.write(str(ue.id).ljust(5))       # ID de l'UE
        file.write(str(ue.assoc_ant).ljust(5))  # ID de l'antenne associée
        file.write("\n")
    file.close()

    file = open("lab3_eq2_pl.txt", "w")
    for ue in ues:
        for ant in antennas:
            pl = pathlossesTab[ue.id][ant.id]
            file.write(str(ue.id).ljust(5))       # ID de l'UE
            file.write(str(ant.id).ljust(8))      # ID de l'antenne
            file.write(str(pl).ljust(20))      # Pathloss calculé 
            file.write(str(model).ljust(6))      # Modèle utilisé
            file.write(str(scenario).ljust(6))   # Scénario de propagation
            file.write(str(check_visibility(vis_filename, ue.id, ant.id)).ljust(6))
            file.write("\n")
    file.close()

    #Simulation de la transmission de l'information
    tstart = get_from_dict("tstart",data_case)  # temps de début de la sim
    tfinal = get_from_dict("tfinal",data_case)  # temps de fin de la sim
    dt = get_from_dict("dt",data_case)          # intervalle de temps de la simulation
    clock_dict = get_from_dict("CLOCK", data_case)
    seg_filename = get_from_dict("read", clock_dict)

    time_segments = load_time_segments(seg_filename)   # Lecture du fichier de segment (ue_id associé à ti et tf)
    
    # Retourne dans un tableau le nombre de bits transmis par slot pour chaque ue
    for ue in ues:
        current_time = tstart
        while current_time < tfinal:
            debut_slot = current_time
            fin_slot = current_time + dt
            current_slot = int(current_time/dt)
            total_bits = 0
            for segment in time_segments:
                ti = segment['start_time']
                tf = segment['end_time']
                if ue.id == segment['ue_id']:
                    if (ti >= debut_slot) and (tf <= fin_slot):
                        debit = ue.debit                 # Débit de l'UE
                        deltaT = tf - ti                 # Durée de l'intervalle de temps
                        nbits = debit * deltaT           # Nombre de bits générés
                        total_bits += nbits
                    elif (ti <= debut_slot) and (tf >= fin_slot):
                        debit = ue.debit                 # Débit de l'UE
                        deltaT = dt                      # Durée de l'intervalle de temps
                        nbits = debit * deltaT           # Nombre de bits générés
                        total_bits += nbits
                    elif (ti >= debut_slot) and (ti <= fin_slot)  and (tf >= fin_slot):
                        debit = ue.debit                 # Débit de l'UE
                        deltaT = fin_slot - ti           # Durée de l'intervalle de temps
                        nbits = debit * deltaT           # Nombre de bits générés
                        total_bits += nbits
                    elif (ti <= debut_slot) and (tf <= fin_slot) and (tf >= debut_slot):
                        debit = ue.debit                 # Débit de l'UE
                        deltaT = tf - debut_slot         # Durée de l'intervalle de temps
                        nbits = debit * deltaT           # Nombre de bits générés
                        total_bits += nbits
            ue.bit_par_slot.append(int(total_bits))        
            ue.timeslots.append(current_time)         
            current_time += dt
            
    # Calcul des bits par slot pour chaque antenne
    for ant in antennas:
        ant.bit_par_slot = []
        ant.timeslots = []
        ant.slot_ues = []
        current_time = tstart
        while current_time < tfinal:
            tab_slot_ues = []
            current_slot = int(current_time/dt)
            bits_this_slot = 0
            for ueID in ant.assoc_ues:
                ue = ues[ueID]
                bits_this_slot += ue.bit_par_slot[current_slot]
                if(ue.bit_par_slot[current_slot] != 0):
                    tab_slot_ues.append(ue.id)
            ant.bit_par_slot.append(int(bits_this_slot))
            ant.timeslots.append(current_time)
            ant.slot_ues.append(tab_slot_ues)
            current_time += dt
    return (antennas,ues)

#----- graph -----

def plot_total_bits_per_timeslot(ues):
    """
    Draws a histogram showing the total bits sent by all UEs in each time slot.
    
    Args:
        ues: List of UE objects with bit_par_slot and timeslots attributes
    """
    
    # Initialize data
    if not ues or len(ues) == 0 or len(ues[0].timeslots) == 0:
        print("No data available to plot")
        return
    
    num_slots = len(ues[0].timeslots)
    timeslots = ues[0].timeslots  # Get timeslots from first UE (they should be same for all)
    total_bits_per_slot = [0] * num_slots
    
    # Sum up bits from all UEs for each time slot
    for ue in ues:
        for slot_idx in range(num_slots):
            if slot_idx < len(ue.bit_par_slot):
                total_bits_per_slot[slot_idx] += ue.bit_par_slot[slot_idx]
    
    # Create histogram
    plt.figure(figsize=(10, 6))
    plt.bar(timeslots, total_bits_per_slot, width=0.8, edgecolor='black')
    
    # Add labels and title
    plt.title('Total Bits Sent by All UEs per Time Slot')
    plt.xlabel('Time Slot (ms)')
    plt.ylabel('Total Bits Sent')
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    
    # Format x-axis to show integer values
    plt.xticks(timeslots)
    
    # Add total count as text above each bar
    for i, v in enumerate(total_bits_per_slot):
        plt.text(timeslots[i], v + max(total_bits_per_slot)*0.02, 
                 str(v), ha='center', fontweight='bold')
    
    # Save figure
    plt.tight_layout()
    plt.savefig('lab3_eq2_total_bits_histogram.pdf')
    plt.close()
    
    print("Histogram saved as 'lab3_eq2_total_bits_histogram.pdf'")


def plot_data_by_ue_type(ues):
    """
    Crée un graphique à barres montrant le total des bits envoyés par type d'UE (App1 vs App2).
    """
    
    
    # Initialiser les compteurs
    app1_total = 0
    app2_total = 0
    
    # Calculer le total pour chaque type d'application
    for ue in ues:
        total_bits = sum(ue.bit_par_slot)
        if ue.app == "app1":
            app1_total += total_bits
        elif ue.app == "app2":
            app2_total += total_bits
    
    # Créer le graphique
    plt.figure(figsize=(8, 6))
    plt.bar(["App1", "App2"], [app1_total, app2_total], color=['blue', 'orange'])
    
    # Ajouter les labels et le titre
    plt.title('Total des bits envoyés par type d\'application')
    plt.ylabel('Nombre de bits')
    plt.xlabel('Type d\'application')
    
    # Ajouter les valeurs au-dessus des barres
    plt.text("App1", app1_total + max(app1_total, app2_total)*0.02, 
             str(app1_total), ha='center', fontweight='bold')
    plt.text("App2", app2_total + max(app1_total, app2_total)*0.02, 
             str(app2_total), ha='center', fontweight='bold')
    
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    plt.tight_layout()
    plt.savefig('lab3_eq2_bits_par_application.pdf')
    plt.close()

def plot_antenna_load_distribution(antennas):
    """
    Crée un graphique à secteurs montrant la distribution de la charge entre les antennes.
    """
    import matplotlib.pyplot as plt
    
    # Calculer la charge totale pour chaque antenne
    antenna_loads = [sum(ant.bit_par_slot) for ant in antennas]
    antenna_ids = [f"Antenne {ant.id}" for ant in antennas]
    
    # Créer le graphique à secteurs
    plt.figure(figsize=(10, 8))
    plt.pie(antenna_loads, labels=antenna_ids, autopct='%1.1f%%', 
            startangle=90, shadow=True)
    plt.axis('equal')  # Pour avoir un cercle parfait
    
    plt.title('Distribution de la charge entre les antennes')
    plt.tight_layout()
    plt.savefig('lab3_eq2_distribution_charge.pdf')
    plt.close()

def plot_ue_activity_heatmap(ues):
    """
    Crée une heatmap montrant l'activité des UEs au fil du temps.
    Plus la couleur est foncée, plus l'UE envoie de bits.
    """
    
    
    # Limiter aux 20 premiers UEs pour la lisibilité
    max_ues = min(20, len(ues))
    selected_ues = ues[:max_ues]
    
    # Créer une matrice d'activité
    if len(selected_ues) == 0 or len(selected_ues[0].timeslots) == 0:
        print("Pas de données disponibles pour la heatmap")
        return
        
    num_slots = len(selected_ues[0].timeslots)
    activity_matrix = np.zeros((max_ues, num_slots))
    
    # Remplir la matrice avec les données d'activité
    for i, ue in enumerate(selected_ues):
        for j in range(min(num_slots, len(ue.bit_par_slot))):
            activity_matrix[i, j] = ue.bit_par_slot[j]
    
    # Créer la heatmap
    plt.figure(figsize=(12, 8))
    sns.heatmap(activity_matrix, cmap="YlOrRd", 
                xticklabels=selected_ues[0].timeslots,
                yticklabels=[f"UE {ue.id}" for ue in selected_ues])
    
    plt.title('Heatmap d\'activité des UEs (bits envoyés par slot de temps)')
    plt.xlabel('Slot de temps (ms)')
    plt.ylabel('ID de l\'UE')
    plt.tight_layout()
    plt.savefig('lab3_eq2_activite_ues_heatmap.pdf')
    plt.close()

def plot_cumulative_data_transfer(ues):
    """
    Crée une courbe montrant le transfert cumulatif de données au fil du temps.
    """
    import matplotlib.pyplot as plt
    import numpy as np
    
    if len(ues) == 0 or len(ues[0].timeslots) == 0:
        print("Pas de données disponibles pour le graphique cumulatif")
        return
        
    num_slots = len(ues[0].timeslots)
    timeslots = ues[0].timeslots
    
    # Calculer le total par slot
    total_per_slot = [0] * num_slots
    for ue in ues:
        for i in range(min(num_slots, len(ue.bit_par_slot))):
            total_per_slot[i] += ue.bit_par_slot[i]
    
    # Calculer les valeurs cumulatives
    cumulative = np.cumsum(total_per_slot)
    
    # Créer le graphique
    plt.figure(figsize=(10, 6))
    plt.plot(timeslots, cumulative, marker='o', linestyle='-', linewidth=2)
    
    plt.title('Transfert cumulatif de données au fil du temps')
    plt.xlabel('Temps (ms)')
    plt.ylabel('Bits cumulatifs')
    plt.grid(True)
    plt.xticks(timeslots)
    
    # Ajouter des annotations pour les points clés
    for i, val in enumerate(cumulative):
        if i % 2 == 0:  # Annoter seulement quelques points pour éviter l'encombrement
            plt.annotate(f"{val:,}", (timeslots[i], val), 
                         textcoords="offset points", xytext=(0,10), ha='center')
    
    plt.tight_layout()
    plt.savefig('lab3_eq2_transfert_cumulatif.pdf')
    plt.close()



# -----------


def main(arg):
    #get case file name
    case_file_name = treat_cli_args(arg)

    data_case = read_yaml_file(case_file_name)
    current_dir = os.path.dirname(os.path.abspath(__file__))
    data_devices = read_yaml_file(os.path.join(current_dir, "devices_db.yaml"))
    antennas, ues = lab3(data_case)
    if get_from_dict("COORD_FILES", data_case) is not None:
        if get_from_dict("write", get_from_dict("COORD_FILES", data_case)) is not None:
            write_coords_to_file(antennas, ues, get_from_dict('write', get_from_dict('COORD_FILES', data_case)))

    print("all done")
    #TODO les instructions de main qui vont faire appel aux autres fonctions du programme
    #.....
    
    f = open("lab3_eq2_transmission_ue.txt","w")
    for UE in ues:
        f.write(str(UE.id).ljust(2))
        f.write("\n")
        for slot, time in enumerate(UE.timeslots):
            f.write(str(time).ljust(3))
            f.write(" ")
            f.write(str(UE.bit_par_slot[slot]))
            f.write("\n")

    f = open("lab3_eq2_transmission_ant.txt","w")
    for ant in antennas:
        f.write(str(ant.id).ljust(2))
        f.write("\n")
        for slot, time in enumerate(ant.timeslots):
            f.write(str(time).ljust(3))
            f.write(" : ")
            f.write(str(ant.bit_par_slot[slot]))
            f.write(" ")
            for ue_id in ant.slot_ues[slot]:
                f.write(str(ue_id))
                f.write(" ")
            f.write("\n")
    
    plot_total_bits_per_timeslot(ues)
    plot_data_by_ue_type(ues)
    plot_antenna_load_distribution(antennas)
    plot_ue_activity_heatmap(ues)
    plot_cumulative_data_transfer(ues)

if __name__ == '__main__':
    # sys.argv est une liste qui contient les arguments utilisés lors de l'appel 
    # du programme à partir du CLI. Cette liste est créée automatiquement par Python. Vous devez 
    # juste inscrire l'argument tel que montré ci-dessous.
    main(sys.argv[1:])
